//JSON
//{key:value}
let student = {
    name: "John",
    age: 20,
    marks: 90,
    isPassed: true,
    address: {
        street: "123 Main St",
        city: "Anytown",
        state: "CA",
        zip: 12345
    }
}
console.log(student);
console.log(student.address);
console.log(student.name);