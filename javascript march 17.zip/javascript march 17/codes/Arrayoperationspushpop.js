//Array operations
//push pop
arr3 = ['a','b','d'];
console.log(arr3);
arr3.push('e');
console.log(arr3);
arr3.pop();
console.log(arr3);
