let score = [84, 92, 75, 68, 55, 95, 66, 89, 87, 74];
score.forEach((n)=>{
    console.log(n);
})