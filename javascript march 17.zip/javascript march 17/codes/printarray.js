//Array
//functio
let name = []; //array initialization
let score = [84, 92, 75, 68, 55, 95, 66, 89, 87, 74]; //array declaration
//accessing array element
console.log(score[0]);