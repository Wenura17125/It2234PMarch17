let score = [84, 92, 75, 68, 55, 95, 66, 89, 87, 74];
for(let i=0;i< score.length;i++)
{
    console.log(score[i]);
}
